package com.oraclejava;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class PhoneContreoller {
    
    @RequestMapping(value="/phone", method = RequestMethod.GET) 
        String phone(@ModelAttribute Phone phone) {

            phone.setName("갤럭시");
            phone.setMoney(253000);
            phone.setMonth_money(33000);

        return "phone";
        }

        
        @RequestMapping(value="/phone", method = RequestMethod.POST) 
        String phone_result(@ModelAttribute Phone phone, Model model) {
            
            // 월 할부금 month_phone = (출고가 * 0.059) / 24
            Integer money = phone.getMoney(); // 출고가 고정
            double tax = (money*0.059)/24; // 수수료 계산
            Integer month_money = phone.getMonth_money(); // 33000고정
            double month_phone = money/24; // 할부금 계산

            // 예상 월 납부금액 ex_money 월 통신요금 + 수수료 + 할부금 더한 금액
            double ex_money = month_money + tax + month_phone;

            phone.setEx_money(ex_money);
            phone.setMonth_phone(month_phone);

            model.addAttribute("phone", phone);

        return "phone_result";
    }
}
