package com.oraclejava;

import lombok.Data;

@Data
public class Phone {
    private String name;    // 폰 이름
    private Integer money;    // 출고가
    private double month_phone;    // 월 할부금?
    private Integer month_money;    // 월 통신요금
    private double ex_money;    // 예산 월 납부금액?
    private double tax;     // 할부 수수료 (출고가 * 0.059) / 24
}
